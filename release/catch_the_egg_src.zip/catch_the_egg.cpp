#include "ext.h"
int width = 1280, height = 720;

// point* cable;
// int    n_points    = 20;
// double cable_width = 1000;
double f = 5.0 / 720;
double g = 9.8 * f;
typedef struct {
    double     k, u, dp;
    point *    p, *v, *a;
    bool_pair* constr;
    int        n;
} cable;

cable* cbl;
cable* createCable(point p1, point p2, double Y, double A, double u, double length, int n_points)
{
    cable* c = (cable*)malloc(sizeof(cable));
    c->u = u * f, c->n = n_points + 1, c->dp = length / c->n, c->k = Y * A / (c->dp * f);
    c->p      = (point*)malloc(sizeof(point) * (c->n + 1));
    c->v      = (point*)malloc(sizeof(point) * (c->n + 1));
    c->a      = (point*)malloc(sizeof(point) * (c->n + 1));
    c->constr = (bool_pair*)malloc(sizeof(bool_pair) * (c->n + 1));
    point del = mul(sub(p2, p1), 1.0 / c->n);
    c->p[0]   = p1;
    for (int i = 1; i < c->n; i++)
        c->p[i] = add(c->p[i - 1], del);
    c->p[c->n] = p2;
    for (int i = 0; i <= c->n; i++)
        c->v[i] = {0, 0}, c->a[i] = {0, 0};
    return c;
}
point solveQuadratic(double a, double b, double c)
{
    double D = sqrt(b * b - 4 * a * c);
    return {(-b + D) / (2 * a), (-b - D) / (2 * a)};
}
double calcConstrErr(point r, point r1, point r2, double dp, double minp, double maxp)
{
    double dr1  = norm(sub(r, r1));
    double dr2  = norm(sub(r, r2));
    double err1 = minp <= dr1 && dr1 <= maxp ? 0 : min(fabs(dr1 - minp), fabs(dr1 - maxp));
    double err2 = minp <= dr2 && dr2 <= maxp ? 0 : min(fabs(dr2 - minp), fabs(dr2 - maxp));
    // printf("dr1: %lf, dr2: %lf, min: %lf, max: %lf\n", dr1, dr2, minp, maxp);
    // printf("err1: %lf, err2: %lf\n", err1, err2);
    return exp(err1 / dp) + exp(err2 / dp);
}
void updateCable(cable* c)
{
    // mass-spring model
    // velocity verlet integration
    static double t0    = iGetTime();
    static int    minP  = -1;
    double        Dt    = (iGetTime() - t0);
    static double dt    = 0.01;
    double        N     = Dt / dt;
    double        dm    = 0.05;
    double        k_s   = 0.05;
    double        k_b   = 0.01;
    double        k_d   = 0.00005;
    double        g     = 9.8 * 0.1;
    double        minst = 1;
    double        maxst = 1;
    for (int i = 0; i < N; i++) {
        for (int i = 1; i < c->n; i++) {
            point r1 = c->p[i - 1], r2 = c->p[i + 1];
            // check all modes of constraint and choose which least exceeds constraints
            point  r   = add(c->p[i], add(mul(c->v[i], dt), mul(c->a[i], 0.5 * dt * dt)));
            double err = calcConstrErr(r, r1, r2, c->dp, c->dp * minst, c->dp * maxst);
            // printf("move error: %lf\n", err);
            for (int k = 0; k < 3; k++) {
                point  r_;
                double err_;
                if (k == 0) {
                    // fully constrained
                    r_   = c->p[i];
                    err_ = calcConstrErr(r_, r1, r2, c->dp, c->dp * minst, c->dp * maxst);
                    // printf("fixed error: %lf\n", err_);
                    if (err_ < err) {
                        err     = err_;
                        r       = r_;
                        c->a[i] = c->v[i] = {0, 0};
                    }
                }
                else {
                    // 1 left length constrained
                    // 2 right length constrained
                    int left = k == 1;
                    // only rotate about fixed point if constrained
                    point  dr     = left ? sub(r1, c->p[i]) : sub(r2, c->p[i]);
                    double w      = cross(dr, c->v[i]) / norm2(dr);
                    double al     = cross(dr, c->a[i]) / norm2(dr);
                    double dtheta = w * dt + al * dt * dt / 2;
                    r_            = rotate(c->p[i], dtheta, left ? r1 : r2);
                    err_          = calcConstrErr(r_, r1, r2, c->dp, c->dp * minst, c->dp * maxst);
                    if (err_ < err) {
                        err     = err_;
                        r       = r_;
                        c->v[i] = {-r.y * w, r.x * w};
                        c->a[i] = {-r.y * al, r.x * al};
                    }
                }
            }
            c->p[i]    = r;
            point  dr1 = sub(r1, r), dr2 = sub(r2, r);
            double dr1_ = norm(dr1), dr2_ = norm(dr2);
            /// stretch strain
            point F_s = add(mul(dr1, k_s * (1 - c->dp / dr1_)), mul(dr2, k_s * (1 - c->dp / dr2_)));
            //  bend strain
            point F_b = mul(add(mul(sub(mul(r, 2), add(r1, r2)), dr1_ * dr2_),
                                mul(add(mul(dr1, dr2_ / dr1_), mul(dr2, dr1_ / dr2_)), dot(dr1, dr2))),
                            -k_b / (dr1_ * dr1_ * dr2_ * dr2_) * acos(dot(neg(dr1), dr2) / (dr1_ * dr2_)));
            //  gravity
            point F_g = {0, -g * dm};
            // drag
            point F_d = mul(c->v[i], -norm(c->v[i]) * k_d);
            point a   = mul(add(F_s, add(F_b, add(F_g, F_d))), 1 / dm);
            c->v[i]   = add(c->v[i], mul(add(a, c->a[i]), 0.5));
            c->a[i]   = a;
        }
    }
}

void init() { cbl = createCable({140, height / 2.0}, {1140, height / 2.0}, 2e9, 5e-5, 5.75e-8, 1100, 10); }

void iDraw()
{
    iClear();
    iPath(cbl->p, cbl->n + 1, 5, 0);
    updateCable(cbl);
}

void iMouseMove(int mx, int my) {}

void iMouse(int button, int state, int mx, int my) {}
void iPassiveMouseMove(int, int) {}
void iResize(int w, int h) {}
void iKeyboard(unsigned char key)
{

    // place your codes for other keys here
}

void iSpecialKeyboard(unsigned char key)
{

    // place your codes for other keys here
}

int main()
{
    init();
    iSetTransparency(1);
    iInitializeEx(width, height, "Demo!");
    return 0;
}
